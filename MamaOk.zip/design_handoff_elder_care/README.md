# Handoff: Nocturne Cuidado (elder-care monitoring app)

## Overview
Two-sided prototype for a family safety app: **Laura's app** (the mother — big, simple controls) and **Nacho's app** (the caregiver — dashboard with live location, vitals, alerts, and AI-generated summaries). This is currently a static-data prototype; the goal in Claude Code is to build the real backend, auth, geolocation, biometrics/health data, and AI summarization behind the same UI.

## About the design files
The files in this bundle are **design references built in an internal HTML prototyping format** (custom `{{ }}` template syntax, `sc-if`/`sc-for` tags, a `DCLogic` class) — not production code and not meant to be copied verbatim. Treat them as a precise visual/behavioral spec. Recreate this UI in whatever stack the target codebase uses (React Native / Swift / Kotlin for real mobile apps — recommended, since this needs background location, biometrics, and push notifications, none of which a web app can do reliably; or React if it's staying web-based for now).

## Fidelity
**High-fidelity.** Colors, spacing, type, radii and copy below should be treated as final; recreate them pixel-for-pixel using the design tokens listed.

## Design tokens (from `styles.css`)
- Background `#161826`, surface `#232532`, text `#e9e9ed`
- Accent (single accent, mono scheme) `#9184d9`, with tonal ramps 100–900 (see `styles.css`) for tints/hovers
- Danger/emergency (the one deliberate exception to the mono palette): border/text `#e0716b` / `#f0a29d`, used only for SOS and emergency states
- Font: Inter, headings weight 500, body 400
- Radius: `--radius-md` 8px, `--radius-lg` 14px
- Shadows: `--shadow-sm/md/lg` (hairline edge + soft ambient dark, no flat drop shadows)
- Full token sheet: `styles.css` in this folder

## Screens — Nacho's app (`CuidadoFamiliar.dc.html`)

### 1. Login
Card, centered, 380px max-width, `--color-surface` bg, `--shadow-lg`. Fingerprint-style logo mark, "Nocturne Cuidado" heading, subtitle "Tu cuenta — separada de la de mamá". Below it, a Google-account-chooser-style button: 36px avatar circle "N", name "Nacho" (14px/500), email "nacho@gmail.com" (12px, 60% opacity), small 4-color Google glyph on the right. Tapping starts a ~1.3s "Conectando con Google…" spinner state, then goes to Dashboard.
**Backend need:** real Google OAuth (two separate accounts/tenants — Nacho and Laura must never share a session or see each other's login).

### 2. Dashboard
Header: time-of-day greeting ("Buenos días/tardes/noches" computed from local hour) + "Nacho", a "En zona segura" accent tag, and a 34px avatar button (initial "N") that opens Profile.
Optional emergency banner (red-tinted, appears when `sosActive`): "Emergencia activada" + "Llamar ya" button.
**Map card** (220px tall): stylized dark map (SVG road paths + a park blob, Google-Maps-night-mode inspired, not a literal recreation), a dashed circle = safe zone, a pulsing accent dot with white ring = Laura's live position, label pill "Casa · zona segura" bottom-left.
**Vitals row**: 3 equal cards — heart rate (bpm, live-jittering number), sleep hours, last-movement time-ago. Each: icon + big number + small label.
**AI summary card**: spark icon + "Análisis de IA" kicker + title "Todo indica que está bien" + 3 bullet observations + meta line "Generado a partir de sensores del teléfono y del reloj · se actualiza solo".
**Actions row**: "Mensaje rápido" (secondary) opens a dialog with 3 canned quick-replies to send to Laura; "Llamar" (primary).
**Activity feed**: list of recent alert/event cards (time tag + text) — most recent quick-message sent gets prepended live.

### 3. Profile (from avatar button)
Back link, avatar + name/email, "Conectado con" card showing Laura's linked account (separate account, "Activo" tag), a Notifications list (3 toggle-style rows, currently static "Activas"), "Cerrar sesión" button (clears session, returns to Login).

## Screens — Laura's app (`CuidadoMama.dc.html`)

### 1. Login
"Hola, Laura" + "Entrá con tu cuenta" + the same Google-account-chooser button pattern, personalized to Laura (avatar "L", laura@gmail.com). Same ~1.3s "Conectando…" transition into Home.

### 2. Home
Greeting ("{{ time-of-day }}, Laura"), a large 220px circular primary button "Estoy bien" (check-in — updates a status line "Avisamos a tu familia recién ahora"), a list of 3 quick-call contacts (Nacho, Andrea, Ceci — each a row with avatar, name, "Toca para llamar"/"Llamando…" state, and a call-icon button), a full-width "Necesito ayuda" (SOS) button in the danger color, a reassurance line ("Tu familia puede ver que estás bien"), and a small "Salir" link.
Text sizes here are intentionally larger than the caregiver app (16–18px body vs 12–14px) for an older user's readability. Touch targets are large (48–220px).

### 3. SOS confirm → sent (dialogs)
Tapping "Necesito ayuda" opens a confirm dialog ("¿Pedir ayuda?" / Cancelar / Sí, avisar). Confirming shows a checkmark dialog "Le avisamos a tu familia" then closes.

## Interactions & state (as prototyped, all client-side/mocked)
- `view` state machine per app: `login → auth → dashboard/home → profile` (Nacho) and `scan/login → auth → home` (Laura)
- Session persistence via `localStorage` (`nocturne-familiar-session`, `nocturne-mama-session`) — **replace with real auth tokens/session**
- Heart rate and map-dot position jitter every 2.5s via `setInterval` — **replace with real HealthKit/Google Fit + geolocation streams**
- Alerts array, contacts array, quick-messages are hardcoded arrays — **replace with real data models**

## Backend / AI work to design in Claude Code
1. **Auth**: two independent Google OAuth identities (caregiver, senior), linked as a family pair server-side; session per device.
2. **Geolocation**: background location on Laura's device, geofence (one safe zone, as scoped) with enter/exit events pushed to Nacho's app.
3. **Biometrics**: heart rate, sleep, activity from device health APIs (HealthKit / Health Connect) or a paired wearable; fall/inactivity detection (on-device or wearable-driven).
4. **AI summary**: a backend job that reads recent vitals/movement/location history and produces the 2–3 sentence "Análisis de IA" card shown on the dashboard — should stay factual/pattern-based (see copy above), not diagnostic.
5. **Alerts/notifications**: push notifications to Nacho on SOS, geofence exit, fall/inactivity detection, and Laura's check-ins.
6. **Messaging/calling**: quick-message delivery to Laura's device; call buttons should deep-link to native phone/VoIP.

## Files in this bundle
- `CuidadoFamiliar.dc.html` — caregiver app reference (see syntax note above)
- `CuidadoMama.dc.html` — senior's app reference
- `styles.css` — full design-token sheet
